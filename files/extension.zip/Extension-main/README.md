<h1 align="center">
<sub>
<img src="https://raw.githubusercontent.com/GooseMod/Extension/main/icons/48.png" height="38" width="38">
</sub>
GooseMod for Web
</h1>

<p align="center">
<a href="https://addons.mozilla.org/addon/goosemod-for-web/"><img src="https://user-images.githubusercontent.com/585534/107280546-7b9b2a00-6a26-11eb-8f9f-f95932f4bfec.png" alt="Get GooseMod for Web for Firefox"></a> 
<a href="https://chrome.google.com/webstore/detail/goosemod-for-web/clgkdcccmbjmjdbdgcigpocfkkjeaeld"><img src="https://user-images.githubusercontent.com/585534/107280622-91a8ea80-6a26-11eb-8d07-77c548b28665.png" alt="Get GooseMod for Web for Chromium"></a>
</p>

***

<p align="center">
<strong>A light, secure, and easy to use Discord mod; now in your browser.</strong>
</p>
